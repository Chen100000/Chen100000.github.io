<?php

// 模板来源:
// https://www.microsoftstore.com.cn/surface/surface-pro/p/mic2539
return [
    'description' => 'Microsoft Shop',
    'options' => []
];